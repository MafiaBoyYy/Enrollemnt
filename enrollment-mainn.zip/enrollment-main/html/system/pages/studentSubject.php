<?php
include('header.php');
include('navigation.php');
?>


<?php
include('Students/_subjectsView.php');

?>

<?php
include('footer.php');
?>