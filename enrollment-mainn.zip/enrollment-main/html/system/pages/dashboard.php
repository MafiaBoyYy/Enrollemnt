<?php
include('header.php');
include('navigation.php');
?>
<main>
    <div class="container-fluid">
        <h1 class="mt-4">Dashboard</h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item active">Dashboard</li>
        </ol>

        <div class="card mb-4">

        </div>
</main>
<?php
include('footer.php');
?>