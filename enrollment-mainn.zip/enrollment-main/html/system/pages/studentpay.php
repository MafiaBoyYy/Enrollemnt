<?php
include('header.php');
include('navigation.php');
?>


<?php
include('paypal/CreatePayment.php');

?>

<?php
include('footer.php');
?>