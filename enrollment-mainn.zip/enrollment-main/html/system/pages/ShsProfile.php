<?php
include('header.php');
include('navigation.php');
?>


<?php
include('Students/_EditShsProfile.php');

?>

<?php
include('footer.php');
?>