<?php
include('header.php');
include('navigation.php');
?>


<?php
include('Students/_EditProfile.php');

?>

<?php
include('footer.php');
?>