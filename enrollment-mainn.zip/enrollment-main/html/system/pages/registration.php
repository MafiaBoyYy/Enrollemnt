<?php
include('header.php');
include('navigation.php');
?>


<?php
include('Students/_registrationmain.php');

?>

<?php
include('footer.php');
?>