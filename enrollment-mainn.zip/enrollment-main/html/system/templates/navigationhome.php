<nav id="mainNavbar" class="navbar navbar-dark navbar-expand-md sticky-top">
    <div class="container-fluid">
        <a href="#" class="navbar-brand"><img style="height: 90px;" src="./assets/img/academialogo.png" alt="logo" />Academia School</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarResponsive">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item active"><a class="nav-link" href="./homepage.php">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="./admision.php">Admission</a></li>
                <li class="nav-item"><a class="nav-link" href="./login.php">Login</a></li>
            </ul>
        </div>
    </div>
</nav>